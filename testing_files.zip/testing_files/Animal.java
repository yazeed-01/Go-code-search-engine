public abstract class Animal {
    // Instance variables
    private String name;
    protected int age;

    // Constructor
    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Abstract method
    public abstract void makeSound();

    // Concrete method
    public void eat() {
        System.out.println(name + " is eating.");
    }

    // Getter and setter
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Method demonstrating a loop
    public void celebrate() {
        for (int i = 0; i < age; i++) {
            System.out.println("Happy Birthday " + name + "!");
        }
    }
}
