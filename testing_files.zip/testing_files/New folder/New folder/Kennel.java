import java.util.ArrayList;
import java.util.List;

public class Kennel {
    // Composition: Kennel has-a list of Dogs
    private List<Dog> dogs;

    // Constructor
    public Kennel() {
        this.dogs = new ArrayList<>();
    }

    // Method to add a dog to the kennel
    public void addDog(Dog dog) {
        dogs.add(dog);
    }

    // Method demonstrating iteration over composed objects
    public void makeAllDogsBark() {
        for (Dog dog : dogs) {
            System.out.print(dog.getName() + " says: ");
            dog.makeSound();
        }
    }

    // Method demonstrating use of composed objects
    public void feedAllDogs() {
        dogs.forEach(Dog::eat);
    }
}

