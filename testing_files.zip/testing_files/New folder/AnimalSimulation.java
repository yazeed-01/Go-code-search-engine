public class AnimalSimulation {
    public static void main(String[] args) {
        // Create instances
        Dog buddy = new Dog("Buddy", 3, "Golden Retriever");
        Dog max = new Dog("Max", 5, "German Shepherd");

        // Demonstrate method calls and inheritance
        buddy.makeSound();
        buddy.eat();
        buddy.fetch();
        buddy.celebrate();

        // Demonstrate loops and data types
        max.countToTen();

        // Demonstrate composition
        Kennel happyPawsKennel = new Kennel();
        happyPawsKennel.addDog(buddy);
        happyPawsKennel.addDog(max);

        happyPawsKennel.makeAllDogsBark();
        happyPawsKennel.feedAllDogs();
    }
}

