public class Dog extends Animal {
    // Additional instance variable
    private String breed;

    // Constructor
    public Dog(String name, int age, String breed) {
        super(name, age);
        this.breed = breed;
    }

    // Implementation of abstract method
    @Override
    public void makeSound() {
        System.out.println("Woof! Woof!");
    }

    // Additional method
    public void fetch() {
        System.out.println(getName() + " is fetching the ball.");
    }

    // Method demonstrating different data types and a loop
    public void countToTen() {
        int count = 0;
        double decimal = 0.5;
        boolean isEven = true;

        while (count < 10) {
            count++;
            decimal += 0.5;
            isEven = !isEven;
            System.out.println("Count: " + count + ", Decimal: " + decimal + ", Is Even: " + isEven);
        }
    }
}

