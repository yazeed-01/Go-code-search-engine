public class File1 {
    public static void main(String[] args) {
        System.out.println("This is File 1");
        int x = 10;
        int y = 20;
        int result = add(x, y);
        System.out.println("Result: " + result);
    }

    public static int add(int a, int b) {
        return a + b;
    }
}
