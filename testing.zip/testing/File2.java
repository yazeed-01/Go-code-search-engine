public class File2 {
    public static void main(String[] args) {
        System.out.println("This is File 2");
        int a = 30;
        int b = 40;
        int sum = add(a, b);
        System.out.println("Sum: " + sum);
    }

    public static int add(int a, int b) {
        return a + b;
    }
}
