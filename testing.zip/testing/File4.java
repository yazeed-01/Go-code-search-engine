public class File4 {
    public static void main(String[] args) {
        System.out.println("This is File 4");
        int num = 100;
        String result = numberToString(num);
        System.out.println("Result: " + result);
    }

    public static String numberToString(int num) {
        return String.valueOf(num);
    }
}
